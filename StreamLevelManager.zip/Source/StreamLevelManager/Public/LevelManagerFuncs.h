// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "LevelManagerFuncs.generated.h"

/**
 * 
 */
UCLASS()
class STREAMLEVELMANAGER_API ULevelManagerFuncs : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
};
